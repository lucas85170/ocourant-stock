import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Search, Plus, Package, Boxes, Euro, Camera, X, Pencil, Trash2,
  Download, MessageCircle, LayoutDashboard, MoreHorizontal, ChevronDown,
  SlidersHorizontal, Zap, Droplets, Cable, CircleHelp, Check, ArrowDownUp
} from 'lucide-react';
import './styles.css';

const CATEGORIES = ['Électricité', 'Plomberie', 'Câblage', 'Autre'];
const UNITS = ['pièce', 'mètre', 'rouleau', 'boîte', 'lot', 'paire', 'kg', 'litre'];
const initialItems = [];

function money(value) {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(Number(value || 0));
}
function readItems() {
  try { return JSON.parse(localStorage.getItem('ocourant-stock-items') || '[]'); }
  catch { return initialItems; }
}
function App() {
  const [items, setItems] = useState(readItems);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('Tous');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [activeTab, setActiveTab] = useState('Aperçu');
  const [sortBy, setSortBy] = useState('name');
  const [notice, setNotice] = useState('');
  const [form, setForm] = useState(emptyForm());

  function emptyForm() {
    return { name: '', category: 'Électricité', reference: '', quantity: '1', unit: 'pièce', price: '', margin: '', notes: '', photo: '' };
  }
  useEffect(() => { localStorage.setItem('ocourant-stock-items', JSON.stringify(items)); }, [items]);
  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => setNotice(''), 2600);
    return () => clearTimeout(timer);
  }, [notice]);

  const filtered = useMemo(() => {
    const q = query.trim().toLocaleLowerCase('fr');
    return items.filter(item => {
      const matchesCategory = category === 'Tous' || item.category === category;
      const haystack = [item.name, item.reference, item.category, item.notes].join(' ').toLocaleLowerCase('fr');
      return matchesCategory && (!q || haystack.includes(q));
    }).sort((a, b) => sortBy === 'quantity' ? Number(b.quantity) - Number(a.quantity) : a.name.localeCompare(b.name, 'fr'));
  }, [items, query, category, sortBy]);

  const totalQuantity = items.reduce((sum, item) => sum + Number(item.quantity || 0), 0);
  const totalValue = items.reduce((sum, item) => sum + Number(item.quantity || 0) * Number(item.price || 0), 0);

  function openNew() {
    setEditing(null); setForm(emptyForm()); setModalOpen(true);
  }
  function openEdit(item) {
    setEditing(item.id);
    setForm({ ...emptyForm(), ...item, quantity: String(item.quantity), price: String(item.price ?? ''), margin: String(item.margin ?? '') });
    setModalOpen(true);
  }
  function saveItem(e) {
    e.preventDefault();
    if (!form.name.trim()) return;
    const record = {
      ...form, name: form.name.trim(), quantity: Math.max(0, Number(form.quantity || 0)),
      price: Math.max(0, Number(form.price || 0)), margin: Number(form.margin || 0),
      id: editing || (globalThis.crypto?.randomUUID?.() ?? String(Date.now()))
    };
    setItems(current => editing ? current.map(item => item.id === editing ? record : item) : [record, ...current]);
    setModalOpen(false); setNotice(editing ? 'Article modifié.' : 'Article ajouté au stock.');
  }
  function removeItem(id) {
    if (!window.confirm('Supprimer cet article du stock ?')) return;
    setItems(current => current.filter(item => item.id !== id));
    setNotice('Article supprimé.');
  }
  function exportItems() {
    const blob = new Blob([JSON.stringify(items, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'ocourant-stock.json'; a.click();
    URL.revokeObjectURL(url);
    setNotice('Export JSON préparé.');
  }
  function setField(key, value) { setForm(current => ({ ...current, [key]: value })); }

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand-mark"><Zap size={20} strokeWidth={2.7} /></div>
      <div className="brand-copy"><div className="brand-name">O’COURANT <span>STOCK</span></div><div className="brand-sub">GESTION DU MATÉRIEL</div></div>
      <button className="icon-button header-menu" aria-label="Plus d'options" onClick={exportItems}><MoreHorizontal size={23}/></button>
    </header>

    <main className="main-content">
      <div className="workspace-label"><span className="status-dot"></span> ESPACE ENTREPRISE <span className="label-separator">•</span> GESTION DU MATÉRIEL</div>
      <section className="hero">
        <div>
          <p className="eyebrow">TON ESPACE DE TRAVAIL</p>
          <h1>Mon stock<span className="title-dot">.</span></h1>
          <p className="hero-subtitle">Électricité · Plomberie · Câblage</p>
        </div>
        <div className="hero-icon"><Package size={31} strokeWidth={1.6}/></div>
      </section>

      <section className="stats-grid" aria-label="Statistiques du stock">
        <div className="stat-card"><div className="stat-icon"><Boxes size={17}/></div><span className="stat-label">ARTICLES</span><strong>{items.length}</strong><span className="stat-foot">références</span></div>
        <div className="stat-card"><div className="stat-icon"><Package size={17}/></div><span className="stat-label">QUANTITÉ TOTALE</span><strong>{totalQuantity.toLocaleString('fr-FR')}</strong><span className="stat-foot">unités en stock</span></div>
        <div className="stat-card"><div className="stat-icon"><Euro size={17}/></div><span className="stat-label">VALEUR DU STOCK</span><strong className="value-number">{money(totalValue)}</strong><span className="stat-foot">valeur d’achat</span></div>
      </section>

      <section className="inventory-section">
        <div className="section-heading"><div><p className="eyebrow">INVENTAIRE</p><h2>Articles en stock <span className="count-pill">{filtered.length}</span></h2></div><button className="add-button" onClick={openNew}><Plus size={17}/> <span>Ajouter</span></button></div>
        <label className="search-field"><Search size={19}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Rechercher un article..." aria-label="Rechercher un article"/>{query && <button aria-label="Effacer la recherche" onClick={() => setQuery('')}><X size={16}/></button>}</label>
        <div className="filter-row" aria-label="Filtrer par catégorie">
          {['Tous', ...CATEGORIES].map((item, i) => <button key={item} className={`filter-chip ${category === item ? 'selected' : ''}`} onClick={() => setCategory(item)}>{i === 1 && <Zap size={13}/ >}{i === 2 && <Droplets size={13}/ >}{i === 3 && <Cable size={13}/ >}{item}</button>)}
        </div>
        <div className="list-toolbar"><span>{query || category !== 'Tous' ? `${filtered.length} résultat${filtered.length > 1 ? 's' : ''}` : 'VOTRE INVENTAIRE'}</span><button className="sort-button" onClick={() => setSortBy(v => v === 'name' ? 'quantity' : 'name')}><ArrowDownUp size={14}/>{sortBy === 'name' ? 'Nom' : 'Quantité'} <ChevronDown size={13}/></button></div>

        {filtered.length === 0 ? <div className="empty-state">
          <div className="empty-art"><div className="empty-circle"><Package size={34} strokeWidth={1.5}/></div><span className="spark spark-one">✳</span><span className="spark spark-two">·</span></div>
          <h3>{items.length === 0 ? 'Ton stock est vide' : 'Aucun article trouvé'}</h3>
          <p>{items.length === 0 ? 'Ajoute ton premier article pour commencer à suivre ton matériel.' : 'Essaie un autre mot-clé ou change le filtre de catégorie.'}</p>
          {items.length === 0 && <button className="add-button empty-add" onClick={openNew}><Plus size={17}/> Ajouter un article</button>}
        </div> : <div className="item-list">{filtered.map(item => <article className="item-card" key={item.id}>
          <div className="item-thumb">{item.photo ? <img src={item.photo} alt=""/> : <CategoryIcon category={item.category}/>}</div>
          <div className="item-info"><div className="item-name">{item.name}</div><div className="item-meta">{item.reference ? `${item.reference} · ` : ''}{item.category}</div><div className="item-quantity">{item.quantity} {item.unit}{item.price ? <span> · {money(item.price)} / unité</span> : null}</div></div>
          <div className="item-actions"><button aria-label={`Modifier ${item.name}`} onClick={() => openEdit(item)}><Pencil size={15}/></button><button aria-label={`Supprimer ${item.name}`} onClick={() => removeItem(item.id)}><Trash2 size={15}/></button></div>
        </article>)}</div>}
      </section>
      <div className="utility-row"><button onClick={exportItems}><Download size={16}/> Exporter mon stock (JSON)</button><span>Enregistré sur cet appareil</span></div>
    </main>

    <nav className="bottom-nav" aria-label="Navigation principale">
      <button className={activeTab === 'Chat' ? 'active' : ''} onClick={() => {setActiveTab('Chat');setNotice('La messagerie sera disponible dans une prochaine version.')}}><MessageCircle size={20}/><span>Chat</span></button>
      <button className={activeTab === 'Aperçu' ? 'active' : ''} onClick={() => {setActiveTab('Aperçu');window.scrollTo({top:0,behavior:'smooth'});}}><LayoutDashboard size={20}/><span>Aperçu</span></button>
      <button className={activeTab === 'Plus' ? 'active' : ''} onClick={() => {setActiveTab('Plus');setNotice('Utilise le menu export pour sauvegarder tes données.')}}><MoreHorizontal size={21}/><span>Plus</span></button>
    </nav>

    {notice && <div className="toast" role="status"><Check size={16}/>{notice}</div>}

    {modalOpen && <div className="modal-backdrop" onMouseDown={e => {if (e.target === e.currentTarget) setModalOpen(false);}}>
      <section className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <div className="modal-heading"><div><p className="eyebrow">{editing ? 'METTRE À JOUR' : 'NOUVELLE RÉFÉRENCE'}</p><h2 id="modal-title">{editing ? 'Modifier l’article' : 'Nouvel article'}</h2></div><button className="icon-button" aria-label="Fermer" onClick={() => setModalOpen(false)}><X size={21}/></button></div>
        <form onSubmit={saveItem}>
          <label className="photo-upload"><Camera size={21}/><span>{form.photo ? 'Photo ajoutée' : 'Ajouter une photo'}</span><small>Facultatif</small><input type="file" accept="image/*" capture="environment" onChange={e => {const file=e.target.files?.[0]; if(file){const reader=new FileReader();reader.onload=()=>setField('photo',reader.result);reader.readAsDataURL(file);}}}/>{form.photo && <img src={form.photo} alt="Aperçu de l’article"/>}</label>
          <div className="form-field"><label htmlFor="item-name">Article <span>*</span></label><input id="item-name" required autoFocus value={form.name} onChange={e => setField('name',e.target.value)} placeholder="Ex. Disjoncteur 20A"/></div>
          <div className="form-grid"><div className="form-field"><label htmlFor="item-category">Catégorie</label><select id="item-category" value={form.category} onChange={e => setField('category',e.target.value)}>{CATEGORIES.map(c=><option key={c}>{c}</option>)}</select></div><div className="form-field"><label htmlFor="item-ref">Réf. fournisseur</label><input id="item-ref" value={form.reference} onChange={e => setField('reference',e.target.value)} placeholder="Ex. REF-102"/></div></div>
          <div className="form-grid"><div className="form-field"><label htmlFor="item-qty">Quantité</label><input id="item-qty" type="number" min="0" step="any" required value={form.quantity} onChange={e => setField('quantity',e.target.value)}/></div><div className="form-field"><label htmlFor="item-unit">Unité</label><select id="item-unit" value={form.unit} onChange={e => setField('unit',e.target.value)}>{UNITS.map(u=><option key={u}>{u}</option>)}</select></div></div>
          <div className="form-grid"><div className="form-field"><label htmlFor="item-price">Prix unitaire (€)</label><input id="item-price" type="number" min="0" step="0.01" value={form.price} onChange={e => setField('price',e.target.value)} placeholder="0,00"/></div><div className="form-field"><label htmlFor="item-margin">Marge unitaire (€)</label><input id="item-margin" type="number" step="0.01" value={form.margin} onChange={e => setField('margin',e.target.value)} placeholder="0,00"/></div></div>
          <div className="form-field"><label htmlFor="item-notes">Notes</label><textarea id="item-notes" rows="3" value={form.notes} onChange={e => setField('notes',e.target.value)} placeholder="Informations complémentaires..."/></div>
          <div className="modal-actions"><button type="button" className="cancel-button" onClick={() => setModalOpen(false)}>Annuler</button><button type="submit" className="save-button"><Check size={17}/>{editing ? 'Enregistrer' : 'Ajouter au stock'}</button></div>
        </form>
      </section>
    </div>}
  </div>;
}
function CategoryIcon({category}) {
  if(category==='Électricité') return <Zap size={21}/>;
  if(category==='Plomberie') return <Droplets size={21}/>;
  if(category==='Câblage') return <Cable size={21}/>;
  return <CircleHelp size={21}/>;
}

createRoot(document.getElementById('root')).render(<React.StrictMode><App/></React.StrictMode>);
